export const THEMES = {
  LIGHT: "light",
  DARK: "dark"
};