import { useTheme } from "@mui/material";

const ErrorPage = () => {
  const theme = useTheme();

  return (
    "404"
  );
};

export default ErrorPage;
